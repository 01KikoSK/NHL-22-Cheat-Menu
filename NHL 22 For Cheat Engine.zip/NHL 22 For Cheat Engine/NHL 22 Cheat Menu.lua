-- NHL 22 Cheat Menu

-- Create a menu
menu = createMenu("NHL 22 Cheats")

-- Add a submenu for player cheats
playerMenu = createSubMenu("Player Cheats", menu)

-- Add a cheat to give infinite stamina
createCheckbox("Infinite Stamina", playerMenu, function(on)
    if on then
        -- Code to give infinite stamina
        writeInteger("stamina_address", 100)
    else
        -- Code to reset stamina
        writeInteger("stamina_address", 50)
    end
end)

-- Add a cheat to unlock all players
createCheckbox("Unlock All Players", playerMenu, function(on)
    if on then
        -- Code to unlock all players
        writeInteger("player_unlock_address", 1)
    else
        -- Code to lock all players
        writeInteger("player_unlock_address", 0)
    end
end)

-- Add a submenu for game cheats
gameMenu = createSubMenu("Game Cheats", menu)

-- Add a cheat to win the current game
createCheckbox("Win Current Game", gameMenu, function(on)
    if on then
        -- Code to win the current game
        writeInteger("game_win_address", 1)
    else
        -- Code to reset game win status
        writeInteger("game_win_address", 0)
    end
end)

-- Add a cheat to unlock all arenas
createCheckbox("Unlock All Arenas", gameMenu, function(on)
    if on then
        -- Code to unlock all arenas
        writeInteger("arena_unlock_address", 1)
    else
        -- Code to lock all arenas
        writeInteger("arena_unlock_address", 0)
    end
end)